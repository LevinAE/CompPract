#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

int main() {
    // Индексная переменная:
    int k;
    // Аргумент функции и "рабочие" переменные:
    double p, sum = 0.0;
    const double epsilon = 1e-6; // Заданная точность

    // Вычисление ряда:
    for (k = 1;; k++) {
        p = 17.0 / pow(2.0, k-1) + pow(-1.0, k-1) / (2.0 * pow(3.0, k-1));
        if (fabs(p) < epsilon) {
            break;
        }
        sum += p;
    }

    // Результат:
    cout << "sum = " << fixed << setprecision(10) << sum << endl;
    return 0;
}