#include <iostream>
#include <iomanip>
#include <cmath>

using namespace std;

// Граница ряда:
const int n_max = 100;
int main() {
    // Аргумент функции и "рабочие" переменные:
    double x, q, p, sum = 0;
    // Индексная переменная:
    int k;
    const double epsilon = 1e-6; // Заданная точность
    cout << "Enter x = ";
    cin >> x;
    q = 1.0; // Начальное значение q для ряда
    // Вычисление ряда:
    for (k = 1; k <= n_max; k++) {
        p = (pow(-1, k)) / (sin(k * x) + 17 + pow(k, 2));
        q *= p;
        sum += q;

        if (fabs(q) < epsilon) {
            break;
        }
    }
    // Результат:
    cout << "f(" << x << ") = " << fixed << setprecision(12) << sum << endl;
    return 0;
}