import random
import math

# Генерация случайных параметров гиперболы и точки
def generate_random_hyperbola():
    a = random.uniform(1, 10)
    b = random.uniform(1, 10)
    h = random.uniform(-10, 10)
    k = random.uniform(-10, 10)
    return a, b, h, k

def generate_random_point():
    x = random.uniform(-20, 20)
    y = random.uniform(-20, 20)
    return x, y

# Проверка принадлежности точки гиперболе
def is_point_on_hyperbola(x, y, a, b, h, k):
    left_side = (x - h)**2 / a**2 - (y - k)**2 / b**2
    return abs(left_side - 1) < 1e-9

# Нахождение координат фокусов гиперболы
def find_focuses(a, b, h, k):
    c = math.sqrt(a**2 + b**2)
    return (h + c, k), (h - c, k)

# Нахождение эксцентриситета гиперболы
def find_eccentricity(a, b):
    return math.sqrt(1 + (b**2 / a**2))

# Нахождение расстояния между директрисами гиперболы
def find_directrices_distance(a, e):
    return 2 * a / e

# Генерация случайных параметров гиперболы и точки
a, b, h, k = generate_random_hyperbola()
x, y = generate_random_point()

print(f"Уравнение гиперболы: ((x - {h})^2 / {a}^2) - ((y - {k})^2 / {b}^2) = 1")
print(f"Точка: ({x}, {y})")

# Проверка принадлежности точки гиперболе
if is_point_on_hyperbola(x, y, a, b, h, k):
    print("Точка принадлежит гиперболе.")
else:
    print("Точка не принадлежит гиперболе.")

# Нахождение координат фокусов гиперболы
f1, f2 = find_focuses(a, b, h, k)
print(f"Координаты фокусов гиперболы: F1{f1}, F2{f2}")

# Нахождение действительной и мнимой полуосей
print(f"Действительная полуось: {a}")
print(f"Мнимая полуось: {b}")

# Нахождение эксцентриситета гиперболы
e = find_eccentricity(a, b)
print(f"Эксцентриситет гиперболы: {e}")

# Нахождение расстояния между директрисами гиперболы
d = find_directrices_distance(a, e)
print(f"Расстояние между директрисами гиперболы: {d}")