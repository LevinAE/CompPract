import random
import math

def generate_random_hyperboloid():
    a = random.uniform(1, 10)
    b = random.uniform(1, 10)
    c = random.uniform(1, 10)
    return a, b, c
def generate_random_plane():
    A = random.uniform(-10, 10)
    B = random.uniform(-10, 10)
    C = random.uniform(-10, 10)
    D = random.uniform(-10, 10)
    return A, B, C, D
def generate_random_line():
    x0 = random.uniform(-10, 10)
    y0 = random.uniform(-10, 10)
    z0 = random.uniform(-10, 10)
    l = random.uniform(-5, 5)
    m = random.uniform(-5, 5)
    n = random.uniform(-5, 5)
    return x0, y0, z0, l, m, n
def generate_random_point():
    x = random.uniform(-20, 20)
    y = random.uniform(-20, 20)
    z = random.uniform(-20, 20)
    return x, y, z
def is_point_on_hyperboloid(x, y, z, a, b, c):
    return math.isclose((x**2 / a**2) + (y**2 / b**2) - (z**2 / c**2), 1, rel_tol=1e-9)
def does_plane_intersect_hyperboloid(A, B, C, D, a, b, c):
    # Мы будем проверять точки на плоскости и смотреть, удовлетворяют ли они уравнению гиперболоида
    # Для этого будем пробегать значения x и y в определенном диапазоне и вычислять соответствующие z

    for x in range(-20, 21):  # Проверяем x от -20 до 20
        for y in range(-20, 21):  # Проверяем y от -20 до 20
            if C != 0:
                z = -(A * x + B * y + D) / C  # Вычисляем z, удовлетворяющее уравнению плоскости
                if is_point_on_hyperboloid(x, y, z, a, b, c):
                    return True
            else:
                # Если C равно 0, плоскость вертикальная, и мы не можем выразить z через x и y
                # В этом случае проверим, удовлетворяют ли случайные (x, y) уравнению плоскости и гиперболоида
                if math.isclose(A * x + B * y + D, 0, rel_tol=1e-9):
                    for z in range(-20, 21):
                        if is_point_on_hyperboloid(x, y, z, a, b, c):
                            return True
    return False
def does_line_intersect_hyperboloid(x0, y0, z0, l, m, n, a, b, c):
    # Решаем квадратное уравнение At^2 + Bt + C = 0 для параметра t
    A = (l**2 / a**2) + (m**2 / b**2) - (n**2 / c**2)
    B = 2 * (x0 * l / a**2 + y0 * m / b**2 - z0 * n / c**2)
    C = (x0**2 / a**2) + (y0**2 / b**2) - (z0**2 / c**2) - 1

    discriminant = B**2 - 4 * A * C

    return discriminant >= 0
# Генерация случайных параметров
a, b, c = generate_random_hyperboloid()
A, B, C, D = generate_random_plane()
x0, y0, z0, l, m, n = generate_random_line()
x, y, z = generate_random_point()

print(f"Уравнение гиперболоида: x^2/{a**2} + y^2/{b**2} - z^2/{c**2} = 1")
print(f"Уравнение плоскости: {A}x + {B}y + {C}z + {D} = 0")
print(f"Уравнение прямой: (x - {x0})/{l} = (y - {y0})/{m} = (z - {z0})/{n}")
print(f"Точка: ({x}, {y}, {z})")

# Проверка принадлежности точки гиперболоиду
if is_point_on_hyperboloid(x, y, z, a, b, c):
    print("Точка принадлежит гиперболоиду.")
else:
    print("Точка не принадлежит гиперболоиду.")

# Проверка пересечения плоскости с гиперболоидом
if does_plane_intersect_hyperboloid(A, B, C, D, a, b, c):
    print("Плоскость пересекает гиперболоид.")
else:
    print("Плоскость не пересекает гиперболоид.")

# Проверка пересечения прямой с гиперболоидом
if does_line_intersect_hyperboloid(x0, y0, z0, l, m, n, a, b, c):
    print("Прямая пересекает гиперболоид.")
else:
    print("Прямая не пересекает гиперболоид.")

