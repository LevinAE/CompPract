#include <iostream>
#include <cmath>

using namespace std;

struct Point {
    double x, y, z;
};

struct Line {
    Point p1, p2;
};

Point generateRandomPoint() {
    return {static_cast<double>(rand() % 100), static_cast<double>(rand() % 100), static_cast<double>(rand() % 100)};
}

Line generateRandomLine() {
    return {generateRandomPoint(), generateRandomPoint()};
}

double dotProduct(Point a, Point b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

Point crossProduct(Point a, Point b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}

double magnitude(Point a) {
    return sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
}

double angleBetweenLines(Line l1, Line l2) {
    Point v1 = {l1.p2.x - l1.p1.x, l1.p2.y - l1.p1.y, l1.p2.z - l1.p1.z};
    Point v2 = {l2.p2.x - l2.p1.x, l2.p2.y - l2.p1.y, l2.p2.z - l2.p1.z};
    double dot = dotProduct(v1, v2);
    double mag1 = magnitude(v1);
    double mag2 = magnitude(v2);
    return acos(dot / (mag1 * mag2)) * (180.0 / M_PI);
}

bool areLinesParallel(Line l1, Line l2) {
    Point v1 = {l1.p2.x - l1.p1.x, l1.p2.y - l1.p1.y, l1.p2.z - l1.p1.z};
    Point v2 = {l2.p2.x - l2.p1.x, l2.p2.y - l2.p1.y, l2.p2.z - l2.p1.z};
    Point cross = crossProduct(v1, v2);
    return magnitude(cross) == 0;
}

double distanceBetweenParallelLines(Line l1, Line l2) {
    Point v1 = {l1.p2.x - l1.p1.x, l1.p2.y - l1.p1.y, l1.p2.z - l1.p1.z};
    Point v2 = {l2.p1.x - l1.p1.x, l2.p1.y - l1.p1.y, l2.p1.z - l1.p1.z};
    Point cross = crossProduct(v1, v2);
    return magnitude(cross) / magnitude(v1);
}

double distanceFromPointToLine(Point p, Line l) {
    Point v = {l.p2.x - l.p1.x, l.p2.y - l.p1.y, l.p2.z - l.p1.z};
    Point w = {p.x - l.p1.x, p.y - l.p1.y, p.z - l.p1.z};
    Point cross = crossProduct(v, w);
    return magnitude(cross) / magnitude(v);
}

bool linesIntersect(Line l1, Line l2, Point &intersection) {
    Point v1 = {l1.p2.x - l1.p1.x, l1.p2.y - l1.p1.y, l1.p2.z - l1.p1.z};
    Point v2 = {l2.p2.x - l2.p1.x, l2.p2.y - l2.p1.y, l2.p2.z - l2.p1.z};
    Point r = {l2.p1.x - l1.p1.x, l2.p1.y - l1.p1.y, l2.p1.z - l1.p1.z};

    Point crossV1V2 = crossProduct(v1, v2);
    Point crossRV1 = crossProduct(r, v1);

    double t = magnitude(crossRV1) / magnitude(crossV1V2);
    if (magnitude(crossV1V2) == 0) {
        return false;
    }
    intersection = {l2.p1.x + t * v2.x, l2.p1.y + t * v2.y, l2.p1.z + t * v2.z};
    return true;
}

int main() {
    srand(time(0));
    Line l1 = generateRandomLine();
    Line l2 = generateRandomLine();
    Point p = generateRandomPoint();

    cout << "Line 1: (" << l1.p1.x << ", " << l1.p1.y << ", " << l1.p1.z << ") to (" << l1.p2.x << ", " << l1.p2.y << ", " << l1.p2.z << ")\n";
    cout << "Line 2: (" << l2.p1.x << ", " << l2.p1.y << ", " << l2.p1.z << ") to (" << l2.p2.x << ", " << l2.p2.y << ", " << l2.p2.z << ")\n";
    cout << "Point: (" << p.x << ", " << p.y << ", " << p.z << ")\n";

    double angle = angleBetweenLines(l1, l2);
    cout << "Angle between lines: " << angle << " degrees\n";

    if (areLinesParallel(l1, l2)) {
        cout << "Lines are parallel.\n";
        double distance = distanceBetweenParallelLines(l1, l2);
        cout << "Distance between parallel lines: " << distance << "\n";
    } else {
        Point intersection;
        if (linesIntersect(l1, l2, intersection)) {
            cout << "Lines intersect at: (" << intersection.x << ", " << intersection.y << ", " << intersection.z << ")\n";
            double distance = distanceFromPointToLine(p, {intersection, intersection});
            cout << "Distance from point to intersection: " << distance << "\n";
        } else {
            cout << "Lines do not intersect.\n";
        }
    }

    double distance1 = distanceFromPointToLine(p, l1);
    double distance2 = distanceFromPointToLine(p, l2);
    cout << "Distance from point to Line 1: " << distance1 << "\n";
    cout << "Distance from point to Line 2: " << distance2 << "\n";

    return 0;
}