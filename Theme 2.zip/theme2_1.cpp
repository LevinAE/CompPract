#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

// Структура для представления точки на плоскости
struct Point {
    double x;
    double y;
};

// Структура для представления прямой на плоскости
struct Line {
    double a;  // Коэффициент при x
    double b;  // Коэффициент при y
    double c;  // Свободный член
};

// Функция для генерации случайного числа в заданном диапазоне
double randomDouble(double min, double max) {
    return min + (double)rand() / RAND_MAX * (max - min);
}

// Функция для вычисления расстояния от точки до прямой
double distancePointToLine(const Point& point, const Line& line) {
    return abs(line.a * point.x + line.b * point.y + line.c) / sqrt(line.a * line.a + line.b * line.b);
}

// Функция для вычисления точки пересечения двух прямых
Point intersectionPoint(const Line& line1, const Line& line2) {
    Point intersection;
    intersection.x = (line2.b * line1.c - line1.b * line2.c) / (line1.a * line2.b - line2.a * line1.b);
    intersection.y = (line1.a * line2.c - line2.a * line1.c) / (line1.a * line2.b - line2.a * line1.b);
    return intersection;
}

// Функция для вычисления расстояния между двумя точками
double distancePoints(const Point& point1, const Point& point2) {
    return sqrt(pow(point1.x - point2.x, 2) + pow(point1.y - point2.y, 2));
}

// Функция для вычисления угла между двумя прямыми
double angleBetweenLines(const Line& line1, const Line& line2) {
    double angle = abs(atan((line2.a - line1.a) / (1 + line1.a * line2.a)));
    return angle * 180 / M_PI; // Преобразование в градусы
}

int main() {
    srand(time(0));

    // Генерация случайных параметров прямых и точки
    Line line1 = {randomDouble(-10, 10), randomDouble(-10, 10), randomDouble(-10, 10)};
    Line line2 = {randomDouble(-10, 10), randomDouble(-10, 10), randomDouble(-10, 10)};
    Point point = {randomDouble(-10, 10), randomDouble(-10, 10)};

    // Вычисление расстояний от точки до прямых
    double distance1 = distancePointToLine(point, line1);
    double distance2 = distancePointToLine(point, line2);

    // Вычисление точки пересечения прямых
    Point intersection = intersectionPoint(line1, line2);

    // Вычисление расстояния от точки до точки пересечения
    double distanceToIntersection = distancePoints(point, intersection);

    // Вычисление угла между прямыми
    double angle = angleBetweenLines(line1, line2);

    // Вывод результатов
    cout << "Прямая 1: y = " << -line1.a / line1.b << "x + " << -line1.c / line1.b << endl;
    cout << "Прямая 2: y = " << -line2.a / line2.b << "x + " << -line2.c / line2.b << endl;
    cout << "Точка: (" << point.x << ", " << point.y << ")" << endl;
    cout << "Расстояние от точки до прямой 1: " << distance1 << endl;
    cout << "Расстояние от точки до прямой 2: " << distance2 << endl;
    cout << "Точка пересечения прямых: (" << intersection.x << ", " << intersection.y << ")" << endl;
    cout << "Расстояние от точки до точки пересечения: " << distanceToIntersection << endl;
    cout << "Угол между прямыми: " << angle << " градусов" << endl;

    return 0;
}