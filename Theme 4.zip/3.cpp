#include <stdio.h>
#include <math.h>

int main() {
    float a[4][4] = {                             // левая часть СЛАУ
            {22.0, -3.0, -8.0, 7.0},
            {-8.0, -22.0, -4.0, -8.0},
            {8.0, -2.0, -18.0, 2.0},
            {7.0, 2.0, -9.0, -24.0}
    };
    float d[4] = {-158.0, 254.0, -108.0, -24.0};  // правая часть СЛАУ
    float x[4] = {0};                             // массив неизвестных значений
    float b[4][4] = {0};
    float g[4] = {0};
    float x1[4] = {0};
    int i, j;
    int k;
    int y = 0;
    float z;
    float xk[4] = {0};
    float e;                                      // погрешность

    k = 0;
    printf("Matrix A of coefficients:\n");
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++)
            printf("%.4f   ", a[i][j]);
        printf("\n");
    }
    printf("\nVector B coefficients:\n");
    for (i = 0; i < 4; i++)
        printf("%.4f  ", d[i]);
    printf("\n\n");
    printf("Input the error:");
    scanf("%f", &e);
    printf("\t%.5f\n\n", e);

    // Первоначальные преобразования
    for (j = 0; j < 4; j++) {
        g[j] = d[j] / a[j][j];
        x[j] = g[j];
        x1[j] = x[j];
        for (i = 0; i < 4; i++) {
            if (i != j) {
                b[j][i] = -a[j][i] / a[j][j];
            } else {
                b[j][i] = 0;
            }
        }
    }

    printf("Transformed matrix:\n");
    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4; j++)
            printf("%.4f   ", b[i][j]);
        printf("\n");
    }
    printf("\n");

    // Организация итерационного процесса (метод Зейделя)
    do {
        y = 0;
        k = k + 1;
        printf("Number of the iteration %d\t\n", k);
        for (j = 0; j < 4; j++) {
            xk[j] = g[j];
            for (i = 0; i < 4; i++) {
                if (i != j) {
                    xk[j] += b[j][i] * x1[i];
                }
            }
            x1[j] = xk[j];
        }

        // Проверка соответствия значений неизвестных заданной точности
        for (j = 0; j < 4; j++) {
            z = fabs(xk[j] - x[j]);
            printf("x[%d]: %.4f, xk[%d]: %.4f\n", j, x[j], j, xk[j]);
            printf("|x[%d]-xk[%d]|=%.4f", j, j, z);
            x[j] = xk[j];
            if (z < e) {
                y++;
            }
            printf("\n");
        }
        printf("\n");
    } while (y != 4);

    printf("Number of iterations :\t");
    printf("%d\n\n", k);
    // Печать результатов
    printf("Result with error %.5f:\n", e);
    for (i = 0; i < 4; i++) {
        printf("\n x[%d]=%.4f ", i, x[i]);
    }
    return 0;
}