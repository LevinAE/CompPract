# Метод наискорейшего спуска (градиентного спуска)
# Запуск программы возможен в on-line компиляторе  https://www.codabrainy.com/en/python-compiler/

import numpy as np
import matplotlib.pyplot as plt


# пропишем функцию потерь (функцию, оптимум которой ищем)
def objective(w1, w2):
    return 7*w1**2 + 2*w1*w2 + 5*w2**2 + w1 - 10*w2


# а также производную по первой
def partial_1(w1):
    return ((14*w1+2*w2+1) / (11-2*w1))


# и второй переменной
def partial_2(w2):
    return ((11-2*w1) / (14*w1+2*w2+1))


# пропишем изначальные веса (точка старта)
w1, w2 = 3, 4

# количество итераций
iter = 100

# и скорость обучения
learning_rate = 0.05

w1_list, w2_list, l_list = [], [], []

# в цикле с заданным количеством итераций
for i in range(iter):
    # будем добавлять текущие веса в соответствующие списки
    w1_list.append(w1)
    w2_list.append(w2)

    # и рассчитывать и добавлять в список текущий уровень ошибки
    l_list.append(objective(w1, w2))

    # также рассчитаем значение частных производных при текущих весах
    par_1 = partial_1(w1)
    par_2 = partial_2(w2)

    # будем обновлять веса в направлении,
    # обратном направлению градиента, умноженному на скорость обучения
    w1 = w1 - learning_rate * par_1
    w2 = w2 - learning_rate * par_2

# выведем итоговые веса модели и значение функции потерь
w1, w2, objective(w1, w2)

fig = plt.figure(figsize=(15, 15))

w1 = np.linspace(-5, 5, 1000)
w2 = np.linspace(-5, 5, 1000)

w1, w2 = np.meshgrid(w1, w2)
f = w1 ** 2 + w2 ** 2

ax = fig.add_subplot(projection='3d')

ax.plot_surface(w1, w2, f, alpha=0.4, cmap='Blues')

ax.text(3, 3.5, 28, 'A', size=25)
ax.text(0, -0.4, 4, 'B', size=25)

ax.set_xlabel('w1', fontsize=15)
ax.set_ylabel('w2', fontsize=15)
ax.set_zlabel('f(w1, w2)', fontsize=15)

# выведем путь алгоритма оптимизации графичесик
ax.plot(w1_list, w2_list, l_list, '.-', c='red')

plt.show()
# выведем путь алгоритма оптимизации в виде последовательности чисел
print('x=', w1_list)
print('y=', w2_list)
print('f=', l_list)
