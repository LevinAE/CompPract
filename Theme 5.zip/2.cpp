#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;

// Функция для вычисления разделенных разностей
void dividedDifferences(double x[], double y[], double diff[][4], int n) {
    for (int i = 0; i < n; i++)
        diff[i][0] = y[i];
    for (int j = 1; j < n; j++) {
        for (int i = 0; i < n - j; i++) {
            diff[i][j] = (diff[i+1][j-1] - diff[i][j-1]) / (x[i+j] - x[i]);
        }
    }
}

// Функция для вычисления значения интерполяционного многочлена Ньютона
double newtonInterpolation(double x[], double diff[][4], int n, double x_star) {
    double result = diff[0][0];
    double product;
    for (int i = 1; i < n; i++) {
        product = 1;
        for (int j = 0; j < i; j++) {
            product *= (x_star - x[j]);
        }
        result += diff[0][i] * product;
    }
    return result;
}

// Главная функция
int main() {
    const int n = 4;
    double x[n] = {0.1 * M_PI, 0.2 * M_PI, 0.3 * M_PI, 0.4 * M_PI};
    double y[n] = {cos(x[0]), cos(x[1]), cos(x[2]), cos(x[3])};

    // Таблица разделенных разностей
    double diff[n][n];
    dividedDifferences(x, y, diff, n);

    // Вывод таблицы разделенных разностей
    cout << "Divided Difference Table:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n - i; j++) {
            cout << setw(12) << diff[i][j] << " ";
        }
        cout << endl;
    }

    // Точка, в которой нужно вычислить значение интерполяционного многочлена
    double x_star = 0.25 * M_PI;
    double y_interpolated = newtonInterpolation(x, diff, n, x_star);
    double y_actual = cos(x_star);

    // Вычисление погрешности
    double error = fabs(y_actual - y_interpolated);

    cout << "\nInterpolated value at x* = 0.25*pi: " << y_interpolated << endl;
    cout << "Actual value at x* = 0.25*pi: " << y_actual << endl;
    cout << "Interpolation error at x* = 0.25*pi: " << error << endl;

    return 0;
}